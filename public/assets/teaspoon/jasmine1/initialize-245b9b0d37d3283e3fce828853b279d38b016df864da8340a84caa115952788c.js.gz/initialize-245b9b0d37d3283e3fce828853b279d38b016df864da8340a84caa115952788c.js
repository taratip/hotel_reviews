(function() {
  Teaspoon.setFramework(Teaspoon.Jasmine1);

}).call(this);
