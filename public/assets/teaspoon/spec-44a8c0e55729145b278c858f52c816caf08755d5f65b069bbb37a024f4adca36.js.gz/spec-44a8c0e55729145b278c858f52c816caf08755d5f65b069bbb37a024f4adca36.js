(function() {
  Teaspoon.Spec = (function() {
    function Spec() {}

    Teaspoon.Utility.include(Spec, Teaspoon.Mixins.FilterUrl);

    return Spec;

  })();

}).call(this);
